import boto3
import pandas as pd
import json
import mysql.connector

s3_client = boto3.client('s3')

my_connection=mysql.connector.connect(host="csv-task-database.c6xwf1g75u1e.ap-south-1.rds.amazonaws.com",
        user="BIadmin",
        passwd="EEZPK4163k@",
        database="csv-task-database"
)
def read_data_from_s3(event):
    bucket_name = event["Records"][0]["s3"]["bucket"]["name"]
    s3_file_name = event["Records"][0]["s3"]["object"]["key"]
    resp = s3_client.get_object(bucket=bucket_name, key = s3_file_name)
    data = resp['Body'].read().decode('utf-8')
    data = data.split(",")
    return data


def lambda_handler(event, context):
    df = pd.read_csv(read_data_from_s3)

    df1 = df.loc[(df['Region']=="Europe")] 

    df2 = df[(df1['Order_Date'] >= '01-04-2015') & (df1['Order_Date'] <= '30-04-2001')]
    
    df2.to_sql(con=my_connection, name='report1',if_exists='replace',index=False)

    return {
        'body':"report generated successfully"
    }


